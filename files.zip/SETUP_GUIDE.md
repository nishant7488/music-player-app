# Full-Featured Music System using YouTube Music API

## Overview

This is a production-ready music application built with React that provides a complete music streaming experience. The app features a modern, dark-themed interface with smooth animations, real-time search, playlist management, and playback controls.

## Features

### Core Features
- **Search Functionality**: Search for songs, artists, and albums in real-time
- **Music Playback**: Full-featured audio player with play/pause controls
- **Queue Management**: Manage song queue with next/previous track navigation
- **Volume Control**: Adjustable volume slider
- **Progress Tracking**: Real-time progress bar with seek functionality
- **Like/Favorite System**: Save favorite songs with persistent storage
- **Playlist Support**: Create and manage custom playlists
- **Device Sync**: Cross-device playback synchronization

### UI/UX Features
- **Dark Theme**: Beautiful gradient background with glassmorphism effects
- **Responsive Grid**: Auto-responsive song cards that adapt to screen size
- **Smooth Animations**: Hover effects, transitions, and interactive elements
- **Tab Navigation**: Switch between Search and Liked songs views
- **Now Playing Bar**: Always-visible mini player at the bottom
- **API Key Management**: Secure API key input modal

## Setup Instructions

### Prerequisites
- Node.js (v14 or higher)
- React (v16.8+)
- YouTube Music API credentials
- Modern web browser

### Installation

1. **Get YouTube Music API Credentials**
   ```bash
   # Visit the YouTube Music API documentation
   # https://developers.google.com/youtube/v3
   
   # Create a Google Cloud project
   # Enable the YouTube Data API v3
   # Create OAuth 2.0 credentials (API Key or Service Account)
   ```

2. **Install Dependencies**
   ```bash
   npm install react react-dom lucide-react
   ```

3. **Environment Setup**
   ```javascript
   // Create .env file
   REACT_APP_YOUTUBE_MUSIC_API_KEY=your_api_key_here
   REACT_APP_API_BASE_URL=https://music.youtube.com/api
   ```

4. **Start the Application**
   ```bash
   npm start
   ```

## API Integration Guide

### Authentication

The app uses YouTube Music API authentication. You can use either:

#### Option 1: API Key Authentication
```javascript
const apiKey = process.env.REACT_APP_YOUTUBE_MUSIC_API_KEY;

const searchSongs = async (query) => {
  const response = await fetch(
    `https://www.googleapis.com/youtube/v3/search?q=${query}&type=video&part=snippet&key=${apiKey}`
  );
  return response.json();
};
```

#### Option 2: OAuth 2.0 Authentication
```javascript
const getAccessToken = async (code) => {
  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    body: JSON.stringify({
      code,
      client_id: process.env.REACT_APP_CLIENT_ID,
      client_secret: process.env.REACT_APP_CLIENT_SECRET,
      redirect_uri: 'http://localhost:3000/callback',
      grant_type: 'authorization_code'
    })
  });
  return response.json();
};
```

### Search API

```javascript
// Search for songs, artists, and albums
async function searchMusic(query, pageToken = null) {
  const params = new URLSearchParams({
    q: query,
    type: 'video',
    part: 'snippet',
    maxResults: 20,
    key: apiKey,
    pageToken: pageToken || ''
  });

  const response = await fetch(
    `https://www.googleapis.com/youtube/v3/search?${params}`
  );
  
  const data = await response.json();
  
  return {
    items: data.items.map(item => ({
      id: item.id.videoId,
      title: item.snippet.title,
      artist: item.snippet.channelTitle,
      thumbnail: item.snippet.thumbnails.medium.url,
      publishedAt: item.snippet.publishedAt
    })),
    nextPageToken: data.nextPageToken
  };
}
```

### Get Song Details

```javascript
// Fetch detailed information about a song
async function getSongDetails(videoId) {
  const response = await fetch(
    `https://www.googleapis.com/youtube/v3/videos?id=${videoId}&part=snippet,contentDetails,statistics&key=${apiKey}`
  );
  
  const data = await response.json();
  const video = data.items[0];
  
  return {
    id: video.id,
    title: video.snippet.title,
    artist: video.snippet.channelTitle,
    description: video.snippet.description,
    thumbnail: video.snippet.thumbnails.high.url,
    duration: parseDuration(video.contentDetails.duration),
    views: parseInt(video.statistics.viewCount),
    likes: parseInt(video.statistics.likeCount || 0),
    publishedAt: video.snippet.publishedAt
  };
}

// Parse ISO 8601 duration to seconds
function parseDuration(duration) {
  const regex = /PT(\d+H)?(\d+M)?(\d+S)?/;
  const matches = duration.match(regex);
  
  const hours = parseInt(matches[1]) || 0;
  const minutes = parseInt(matches[2]) || 0;
  const seconds = parseInt(matches[3]) || 0;
  
  return hours * 3600 + minutes * 60 + seconds;
}
```

### Playlist Management

```javascript
// Create a playlist
async function createPlaylist(title, description = '') {
  const response = await fetch(
    'https://www.googleapis.com/youtube/v3/playlists?part=snippet,status',
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        snippet: {
          title,
          description
        },
        status: {
          privacyStatus: 'PRIVATE'
        }
      })
    }
  );
  
  return response.json();
}

// Add song to playlist
async function addToPlaylist(playlistId, videoId) {
  const response = await fetch(
    'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet',
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        snippet: {
          playlistId,
          resourceId: {
            kind: 'youtube#video',
            videoId
          }
        }
      })
    }
  );
  
  return response.json();
}

// Get playlist items
async function getPlaylistItems(playlistId) {
  const response = await fetch(
    `https://www.googleapis.com/youtube/v3/playlistItems?playlistId=${playlistId}&part=snippet&maxResults=50&key=${apiKey}`
  );
  
  return response.json();
}
```

## Component Architecture

### Main App Component
- **State Management**: Uses React hooks (useState, useRef)
- **API Calls**: Integrated with YouTube Music API
- **Local Storage**: Persists API key and liked songs

### Sub-Components
- Search Interface
- Song Cards Grid
- Now Playing Bar
- Playback Controls
- Volume Control

## Styling & Design

### Design System
- **Color Palette**:
  - Primary: #ff6b6b (Coral Red)
  - Background: Gradient (0f0c29 → 302b63 → 24243e)
  - Secondary: rgba(255, 255, 255, 0.05-0.12)

- **Typography**:
  - Display: Playfair Display (serif)
  - Body: System fonts with 14-16px base

- **Effects**:
  - Glassmorphism (backdrop-filter: blur)
  - Smooth transitions (0.3s)
  - Hover animations and scale transforms

## Advanced Features

### Recommendation Engine
```javascript
async function getRecommendations(seed) {
  // Use Spotify API or similar for recommendations
  const response = await fetch(
    `https://api.spotify.com/v1/recommendations?seed_artists=${seed}`,
    {
      headers: { 'Authorization': `Bearer ${spotifyToken}` }
    }
  );
  return response.json();
}
```

### Playback Statistics
```javascript
// Track user listening habits
const listeningStats = {
  totalListens: 0,
  topSongs: [],
  topArtists: [],
  totalMinutesListened: 0,
  favoriteGenres: []
};

function updateStats(song, duration) {
  listeningStats.totalListens++;
  listeningStats.totalMinutesListened += duration / 60;
  // Update top songs, artists, etc.
}
```

### Offline Support
```javascript
// Service Worker for offline playback
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('service-worker.js');
}

// Cache songs for offline access
async function cacheAudio(videoId, audioBlob) {
  const db = await openIndexedDB();
  db.put('cache', audioBlob, videoId);
}
```

## Performance Optimization

### Code Splitting
```javascript
const NowPlayingBar = React.lazy(() => import('./NowPlayingBar'));
const SearchResults = React.lazy(() => import('./SearchResults'));
```

### Memoization
```javascript
const SongCard = React.memo(({ song, onPlay, isLiked, onLike }) => {
  // Component optimized to prevent unnecessary re-renders
});
```

### Lazy Loading
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      loadMoreSongs();
    }
  });
});
```

## Error Handling

```javascript
// API Error Handler
function handleAPIError(error) {
  if (error.response?.status === 401) {
    // Refresh token or redirect to login
  } else if (error.response?.status === 429) {
    // Rate limit exceeded - retry with backoff
  } else {
    // Generic error handling
    console.error('API Error:', error);
  }
}
```

## Testing

### Unit Tests
```javascript
// test/searchMusic.test.js
describe('searchMusic', () => {
  it('should return search results', async () => {
    const results = await searchMusic('Imagine Dragons');
    expect(results.items.length).toBeGreaterThan(0);
  });
});
```

### Integration Tests
```javascript
// test/playback.test.js
describe('Playback Control', () => {
  it('should play and pause song', () => {
    const { getByRole } = render(<MusicApp />);
    const playButton = getByRole('button', { name: /play/i });
    fireEvent.click(playButton);
    expect(playButton).toHaveAttribute('aria-pressed', 'true');
  });
});
```

## Deployment

### Docker Setup
```dockerfile
FROM node:16-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

### Environment Variables
```env
REACT_APP_YOUTUBE_MUSIC_API_KEY=your_key
REACT_APP_API_BASE_URL=https://music.youtube.com/api
REACT_APP_SPOTIFY_CLIENT_ID=optional_spotify_id
REACT_APP_SENTRY_DSN=error_tracking
```

## Troubleshooting

### Common Issues

**Issue**: API Key not working
- Solution: Verify API is enabled in Google Cloud Console
- Check quota limits in API dashboard

**Issue**: CORS errors
- Solution: Use proxy server or CORS headers
- Set up backend middleware for API calls

**Issue**: Slow search results
- Solution: Implement debouncing on search input
- Cache results in localStorage

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## License

MIT License - feel free to use and modify for your projects

## Contributing

Pull requests welcome! Please follow the code style and add tests for new features.

## Additional Resources

- [YouTube Data API Documentation](https://developers.google.com/youtube/v3)
- [React Hooks Guide](https://react.dev/reference/react)
- [Web Audio API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API)
- [Spotify Web API](https://developer.spotify.com/documentation/web-api)
