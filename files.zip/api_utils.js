/**
 * Music API Utility Functions
 * Provides helper functions for interacting with the backend API
 */

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000/api';

// ==================== SEARCH ====================

export const searchSongs = async (query, limit = 20) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/search?q=${encodeURIComponent(query)}&limit=${limit}`
    );
    if (!response.ok) throw new Error('Search failed');
    return await response.json();
  } catch (error) {
    console.error('Search error:', error);
    throw error;
  }
};

export const searchArtists = async (query, limit = 20) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/search?q=${encodeURIComponent(query)}&type=artist&limit=${limit}`
    );
    if (!response.ok) throw new Error('Artist search failed');
    return await response.json();
  } catch (error) {
    console.error('Artist search error:', error);
    throw error;
  }
};

// ==================== SONG DETAILS ====================

export const getSongDetails = async (videoId) => {
  try {
    const response = await fetch(`${API_BASE_URL}/song/${videoId}`);
    if (!response.ok) throw new Error('Failed to fetch song details');
    return await response.json();
  } catch (error) {
    console.error('Song details error:', error);
    throw error;
  }
};

export const getSongLyrics = async (artist, title) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/lyrics?artist=${encodeURIComponent(artist)}&title=${encodeURIComponent(title)}`
    );
    if (!response.ok) throw new Error('Failed to fetch lyrics');
    return await response.json();
  } catch (error) {
    console.error('Lyrics error:', error);
    return null;
  }
};

// ==================== PLAYLISTS ====================

export const getChannelPlaylists = async (channelId, maxResults = 25) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/playlists/${channelId}?maxResults=${maxResults}`
    );
    if (!response.ok) throw new Error('Failed to fetch playlists');
    return await response.json();
  } catch (error) {
    console.error('Playlists error:', error);
    throw error;
  }
};

export const getPlaylistItems = async (playlistId, maxResults = 50) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/playlist/${playlistId}/items?maxResults=${maxResults}`
    );
    if (!response.ok) throw new Error('Failed to fetch playlist items');
    return await response.json();
  } catch (error) {
    console.error('Playlist items error:', error);
    throw error;
  }
};

// ==================== RECOMMENDATIONS ====================

export const getRecommendations = async (seedVideoId, limit = 20) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/recommendations?seed=${seedVideoId}&limit=${limit}`
    );
    if (!response.ok) throw new Error('Failed to fetch recommendations');
    return await response.json();
  } catch (error) {
    console.error('Recommendations error:', error);
    throw error;
  }
};

// ==================== TRENDS ====================

export const getTrendingSongs = async (region = 'US', limit = 20) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/trending?region=${region}&limit=${limit}`
    );
    if (!response.ok) throw new Error('Failed to fetch trending songs');
    return await response.json();
  } catch (error) {
    console.error('Trending songs error:', error);
    throw error;
  }
};

// ==================== STREAMING ====================

export const getAudioStream = async (videoId) => {
  try {
    const response = await fetch(`${API_BASE_URL}/stream/${videoId}`);
    if (!response.ok) throw new Error('Failed to get audio stream');
    return await response.json();
  } catch (error) {
    console.error('Stream error:', error);
    throw error;
  }
};

// ==================== LOCAL STORAGE ====================

/**
 * Manage liked songs in localStorage
 */
export const likedSongsManager = {
  getAll: () => {
    const liked = localStorage.getItem('likedSongs');
    return liked ? JSON.parse(liked) : {};
  },

  add: (songId, songData) => {
    const liked = likedSongsManager.getAll();
    liked[songId] = {
      ...songData,
      likedAt: new Date().toISOString()
    };
    localStorage.setItem('likedSongs', JSON.stringify(liked));
  },

  remove: (songId) => {
    const liked = likedSongsManager.getAll();
    delete liked[songId];
    localStorage.setItem('likedSongs', JSON.stringify(liked));
  },

  isSongLiked: (songId) => {
    const liked = likedSongsManager.getAll();
    return songId in liked;
  },

  getLikedCount: () => {
    return Object.keys(likedSongsManager.getAll()).length;
  }
};

/**
 * Manage playlists in localStorage
 */
export const playlistManager = {
  getAll: () => {
    const playlists = localStorage.getItem('customPlaylists');
    return playlists ? JSON.parse(playlists) : {};
  },

  create: (name, description = '') => {
    const playlists = playlistManager.getAll();
    const id = `playlist_${Date.now()}`;
    playlists[id] = {
      id,
      name,
      description,
      songs: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    localStorage.setItem('customPlaylists', JSON.stringify(playlists));
    return playlists[id];
  },

  addSong: (playlistId, songData) => {
    const playlists = playlistManager.getAll();
    if (playlists[playlistId]) {
      const songExists = playlists[playlistId].songs.some(s => s.id === songData.id);
      if (!songExists) {
        playlists[playlistId].songs.push(songData);
        playlists[playlistId].updatedAt = new Date().toISOString();
        localStorage.setItem('customPlaylists', JSON.stringify(playlists));
      }
    }
  },

  removeSong: (playlistId, songId) => {
    const playlists = playlistManager.getAll();
    if (playlists[playlistId]) {
      playlists[playlistId].songs = playlists[playlistId].songs.filter(s => s.id !== songId);
      playlists[playlistId].updatedAt = new Date().toISOString();
      localStorage.setItem('customPlaylists', JSON.stringify(playlists));
    }
  },

  delete: (playlistId) => {
    const playlists = playlistManager.getAll();
    delete playlists[playlistId];
    localStorage.setItem('customPlaylists', JSON.stringify(playlists));
  },

  getPlaylist: (playlistId) => {
    const playlists = playlistManager.getAll();
    return playlists[playlistId] || null;
  }
};

/**
 * Manage listening history
 */
export const historyManager = {
  getHistory: () => {
    const history = localStorage.getItem('listeningHistory');
    return history ? JSON.parse(history) : [];
  },

  addToHistory: (songData) => {
    const history = historyManager.getHistory();
    const entry = {
      ...songData,
      playedAt: new Date().toISOString()
    };
    history.unshift(entry);
    // Keep only last 100 items
    if (history.length > 100) {
      history.pop();
    }
    localStorage.setItem('listeningHistory', JSON.stringify(history));
  },

  clearHistory: () => {
    localStorage.removeItem('listeningHistory');
  },

  getRecentSongs: (limit = 10) => {
    return historyManager.getHistory().slice(0, limit);
  }
};

/**
 * Manage user preferences
 */
export const preferencesManager = {
  getPreferences: () => {
    const prefs = localStorage.getItem('userPreferences');
    return prefs ? JSON.parse(prefs) : {
      volume: 70,
      autoplay: true,
      quality: 'high',
      theme: 'dark',
      language: 'en'
    };
  },

  updatePreference: (key, value) => {
    const prefs = preferencesManager.getPreferences();
    prefs[key] = value;
    localStorage.setItem('userPreferences', JSON.stringify(prefs));
  },

  setVolume: (volume) => {
    preferencesManager.updatePreference('volume', volume);
  },

  getVolume: () => {
    return preferencesManager.getPreferences().volume;
  }
};

// ==================== FORMATTING HELPERS ====================

export const formatTime = (seconds) => {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);

  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${secs.toString().padStart(2, '0')}`;
};

export const formatViews = (views) => {
  if (views >= 1000000) {
    return `${(views / 1000000).toFixed(1)}M`;
  }
  if (views >= 1000) {
    return `${(views / 1000).toFixed(1)}K`;
  }
  return views.toString();
};

export const formatDate = (dateString) => {
  const date = new Date(dateString);
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);

  if (date.toDateString() === today.toDateString()) {
    return 'Today';
  }
  if (date.toDateString() === yesterday.toDateString()) {
    return 'Yesterday';
  }

  const diffTime = Math.abs(today - date);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 7) {
    return `${diffDays} days ago`;
  }
  if (diffDays < 30) {
    const weeks = Math.floor(diffDays / 7);
    return `${weeks} week${weeks > 1 ? 's' : ''} ago`;
  }

  return date.toLocaleDateString();
};

// ==================== VALIDATION ====================

export const validateVideoId = (videoId) => {
  return /^[a-zA-Z0-9_-]{11}$/.test(videoId);
};

export const validatePlaylistId = (playlistId) => {
  return /^[a-zA-Z0-9_-]+$/.test(playlistId);
};

export const validateChannelId = (channelId) => {
  return /^UC[a-zA-Z0-9_-]{22}$/.test(channelId);
};

// ==================== ERROR HANDLING ====================

export const handleAPIError = (error, context = '') => {
  console.error(`API Error [${context}]:`, error);

  if (error.message === 'Failed to fetch') {
    return 'Network error. Please check your connection.';
  }

  if (error.response?.status === 401) {
    return 'Authentication failed. Please log in again.';
  }

  if (error.response?.status === 429) {
    return 'Too many requests. Please try again later.';
  }

  if (error.response?.status === 404) {
    return 'Resource not found.';
  }

  if (error.response?.status === 500) {
    return 'Server error. Please try again later.';
  }

  return error.message || 'An error occurred. Please try again.';
};
