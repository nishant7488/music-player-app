# 🎵 Sonic Wave - Music Streaming App - Quick Start Guide

A full-featured music streaming application built with React and YouTube Music API.

## ⚡ 5-Minute Setup

### 1. Prerequisites
```bash
Node.js >= 14.0.0
npm >= 6.0.0
```

### 2. Get YouTube API Key
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a new project
3. Enable "YouTube Data API v3"
4. Create API Key credentials
5. Copy your API key

### 3. Clone & Install
```bash
# Clone or extract the project
cd music-app

# Install dependencies
npm install
```

### 4. Environment Setup
```bash
# Copy the example env file
cp .env.example .env.local

# Edit .env.local and add your YouTube API key
REACT_APP_YOUTUBE_MUSIC_API_KEY=your_api_key_here
REACT_APP_API_BASE_URL=http://localhost:5000/api
```

### 5. Start Development
```bash
# Terminal 1 - Start React app
npm start

# Terminal 2 - Start backend server
npm run server

# OR start both together
npm run dev
```

Visit `http://localhost:3000` in your browser!

---

## 🎯 Core Features

### 🔍 Search
- Search songs, artists, and albums
- Real-time search results with thumbnails
- Pagination support for large result sets

### ▶️ Playback
- Play/pause controls
- Next/previous track navigation
- Progress bar with seek capability
- Volume control
- Real-time duration display

### ❤️ Library Management
- Like/unlike songs
- View liked songs
- Create custom playlists
- Recently played history

### 🎨 Beautiful UI
- Dark theme with gradient background
- Glassmorphism effects
- Smooth animations
- Responsive design

---

## 📦 File Structure

```
music-app/
├── music_app.jsx           # Main React component
├── backend_server.js       # Express backend with API endpoints
├── api_utils.js           # API helper functions
├── package.json           # Dependencies
├── .env.example          # Environment template
├── SETUP_GUIDE.md        # Detailed setup documentation
└── README.md             # This file
```

---

## 🚀 Usage Examples

### Search for Songs
```javascript
import { searchSongs } from './api_utils';

const results = await searchSongs('Imagine Dragons');
console.log(results.items); // Array of songs
```

### Get Song Details
```javascript
import { getSongDetails } from './api_utils';

const details = await getSongDetails('dQw4w9WgXcQ');
console.log(details); // Full song metadata
```

### Like a Song
```javascript
import { likedSongsManager } from './api_utils';

likedSongsManager.add('song_id', { title: 'My Song', artist: 'Artist' });
```

### Create Playlist
```javascript
import { playlistManager } from './api_utils';

const playlist = playlistManager.create('My Favorites', 'My favorite songs');
playlistManager.addSong(playlist.id, { title: 'Song', artist: 'Artist' });
```

---

## 🔧 Configuration

### Backend API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/search?q=query` | Search songs |
| GET | `/api/song/:videoId` | Get song details |
| GET | `/api/lyrics?artist=X&title=Y` | Get song lyrics |
| GET | `/api/trending?region=US` | Get trending songs |
| GET | `/api/recommendations?seed=videoId` | Get recommendations |
| GET | `/api/playlists/:channelId` | Get channel playlists |
| GET | `/api/stream/:videoId` | Get audio stream |

### Environment Variables

```env
# YouTube Music API
REACT_APP_YOUTUBE_MUSIC_API_KEY=your_key
REACT_APP_API_BASE_URL=http://localhost:5000/api

# Optional Services
GENIUS_ACCESS_TOKEN=your_token
SPOTIFY_CLIENT_ID=your_id
REACT_APP_SENTRY_DSN=your_sentry_dsn
```

---

## 🎨 Customization

### Change Theme Colors
Edit the gradient and colors in `music_app.jsx`:
```javascript
background: 'linear-gradient(135deg, #0f0c29, #302b63, #24243e)'
// Change to your preferred colors
```

### Modify Layout
```javascript
// Adjust grid columns for song cards
gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))'
// Change minmax values for different card sizes
```

### Add More Features
- Add shuffle/repeat modes
- Implement queue visualization
- Add equalizer controls
- Integrate with Spotify API
- Add social sharing

---

## 🐛 Troubleshooting

### "API Key Invalid"
- ✅ Verify API is enabled in Google Cloud Console
- ✅ Check quota limits
- ✅ Ensure key has YouTube Data API v3 access

### "CORS Error"
- ✅ Backend server must be running
- ✅ Check API_BASE_URL in .env.local
- ✅ Verify backend is listening on port 5000

### "No Search Results"
- ✅ Check internet connection
- ✅ Verify YouTube API is responding
- ✅ Check browser console for errors

### "Audio Not Playing"
- ✅ YouTube videos must be available in your region
- ✅ Some videos may have embedding disabled
- ✅ Check browser console for specific errors

---

## 📚 Advanced Features

### Implement Offline Support
```javascript
// Register service worker
navigator.serviceWorker.register('service-worker.js');

// Cache songs for offline access
await cacheAudio(videoId, audioBlob);
```

### Add Analytics
```javascript
import * as gtag from './gtag';

gtag.event('song_played', { video_id: videoId });
```

### Implement User Accounts
```javascript
// Google Sign-In
import GoogleLogin from 'react-google-login';

// Save user preferences to database
```

---

## 🧪 Testing

### Run Tests
```bash
npm test
```

### Test Specific Component
```bash
npm test music_app.test.jsx
```

### Example Test
```javascript
describe('MusicApp', () => {
  it('should search for songs', async () => {
    const { getByRole } = render(<MusicApp />);
    const input = getByRole('textbox');
    fireEvent.change(input, { target: { value: 'test' } });
    expect(input.value).toBe('test');
  });
});
```

---

## 📱 Deployment

### Deploy to Vercel
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

### Deploy to Netlify
```bash
# Build the app
npm run build

# Drag and drop 'build' folder to Netlify
# Or use Netlify CLI: netlify deploy --prod
```

### Deploy Backend to Heroku
```bash
# Install Heroku CLI
heroku login

# Deploy
git push heroku main
```

---

## 📖 Additional Resources

- [YouTube Data API Docs](https://developers.google.com/youtube/v3)
- [React Documentation](https://react.dev)
- [Web Audio API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API)
- [Genius API](https://docs.genius.com)

---

## 🤝 Contributing

Found a bug or want to add a feature? Great!

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📄 License

MIT License - feel free to use this project for commercial or personal use.

---

## 💡 Tips & Tricks

1. **Speed Up Search**: Use debouncing to reduce API calls
2. **Save Data**: Cache results to reduce bandwidth
3. **Smooth UX**: Implement lazy loading for large playlists
4. **Better Performance**: Use React.memo for song cards
5. **User Retention**: Add push notifications for new releases

---

## 🎉 You're All Set!

Your music streaming app is ready to rock! 🎸

Have questions? Check the detailed SETUP_GUIDE.md or reach out to the community!

Happy coding! 🚀
