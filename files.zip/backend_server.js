/**
 * YouTube Music API Integration Service
 * Backend server for handling API calls with proper authentication and caching
 */

const express = require('express');
const axios = require('axios');
const cors = require('cors');
const NodeCache = require('node-cache');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const app = express();
const cache = new NodeCache({ stdTTL: 600 }); // 10-minute cache

// Middleware
app.use(cors());
app.use(express.json());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use(limiter);

// Environment variables
const YOUTUBE_API_KEY = process.env.YOUTUBE_API_KEY;
const SPOTIFY_CLIENT_ID = process.env.SPOTIFY_CLIENT_ID;
const SPOTIFY_CLIENT_SECRET = process.env.SPOTIFY_CLIENT_SECRET;
const GENIUS_ACCESS_TOKEN = process.env.GENIUS_ACCESS_TOKEN;

// YouTube API Base URL
const YOUTUBE_API_URL = 'https://www.googleapis.com/youtube/v3';
const SPOTIFY_API_URL = 'https://api.spotify.com/v1';

// ==================== SEARCH ENDPOINTS ====================

/**
 * Search for songs
 * GET /api/search?q=query&type=song&limit=20
 */
app.get('/api/search', async (req, res) => {
  try {
    const { q, type = 'song', limit = 20, pageToken } = req.query;

    // Check cache
    const cacheKey = `search:${q}:${type}`;
    const cachedResult = cache.get(cacheKey);
    if (cachedResult) {
      return res.json(cachedResult);
    }

    const results = await searchYouTubeMusic(q, limit, pageToken);

    // Cache the result
    cache.set(cacheKey, results);

    res.json(results);
  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({ error: 'Search failed', details: error.message });
  }
});

/**
 * Search YouTube for videos
 */
async function searchYouTubeMusic(query, maxResults = 20, pageToken = null) {
  const params = {
    q: query,
    type: 'video',
    part: 'snippet',
    maxResults,
    key: YOUTUBE_API_KEY,
    relevanceLanguage: 'en',
    safeSearch: 'moderate'
  };

  if (pageToken) {
    params.pageToken = pageToken;
  }

  const response = await axios.get(`${YOUTUBE_API_URL}/search`, { params });

  return {
    items: response.data.items.map(item => ({
      id: item.id.videoId,
      type: 'video',
      title: item.snippet.title,
      artist: item.snippet.channelTitle,
      thumbnail: item.snippet.thumbnails.medium.url,
      description: item.snippet.description,
      publishedAt: item.snippet.publishedAt,
      channelId: item.snippet.channelId
    })),
    nextPageToken: response.data.nextPageToken,
    totalResults: response.data.pageInfo.totalResults
  };
}

// ==================== SONG DETAILS ENDPOINTS ====================

/**
 * Get song details
 * GET /api/song/:videoId
 */
app.get('/api/song/:videoId', async (req, res) => {
  try {
    const { videoId } = req.params;

    // Check cache
    const cacheKey = `song:${videoId}`;
    const cachedResult = cache.get(cacheKey);
    if (cachedResult) {
      return res.json(cachedResult);
    }

    const details = await getSongDetails(videoId);
    
    // Cache the result
    cache.set(cacheKey, details);

    res.json(details);
  } catch (error) {
    console.error('Song details error:', error);
    res.status(500).json({ error: 'Failed to fetch song details' });
  }
});

/**
 * Fetch detailed song information from YouTube
 */
async function getSongDetails(videoId) {
  const params = {
    id: videoId,
    part: 'snippet,contentDetails,statistics',
    key: YOUTUBE_API_KEY
  };

  const response = await axios.get(`${YOUTUBE_API_URL}/videos`, { params });

  if (!response.data.items.length) {
    throw new Error('Video not found');
  }

  const video = response.data.items[0];

  return {
    id: video.id,
    title: video.snippet.title,
    artist: video.snippet.channelTitle,
    channelId: video.snippet.channelId,
    description: video.snippet.description,
    thumbnail: video.snippet.thumbnails.high.url,
    duration: parseDuration(video.contentDetails.duration),
    views: parseInt(video.statistics.viewCount || 0),
    likes: parseInt(video.statistics.likeCount || 0),
    comments: parseInt(video.statistics.commentCount || 0),
    publishedAt: video.snippet.publishedAt,
    url: `https://www.youtube.com/watch?v=${videoId}`,
    embeddable: video.contentDetails.contentRating ? true : false
  };
}

/**
 * Parse ISO 8601 duration to seconds
 */
function parseDuration(duration) {
  const regex = /PT(\d+H)?(\d+M)?(\d+S)?/;
  const matches = duration.match(regex);

  const hours = parseInt(matches[1]) || 0;
  const minutes = parseInt(matches[2]) || 0;
  const seconds = parseInt(matches[3]) || 0;

  return hours * 3600 + minutes * 60 + seconds;
}

// ==================== PLAYLIST ENDPOINTS ====================

/**
 * Get channel playlists
 * GET /api/playlists/:channelId
 */
app.get('/api/playlists/:channelId', async (req, res) => {
  try {
    const { channelId } = req.params;
    const { maxResults = 25 } = req.query;

    const params = {
      channelId,
      part: 'snippet,contentDetails',
      maxResults,
      key: YOUTUBE_API_KEY
    };

    const response = await axios.get(`${YOUTUBE_API_URL}/playlists`, { params });

    const playlists = response.data.items.map(playlist => ({
      id: playlist.id,
      title: playlist.snippet.title,
      description: playlist.snippet.description,
      thumbnail: playlist.snippet.thumbnails?.medium?.url,
      itemCount: playlist.contentDetails.itemCount,
      publishedAt: playlist.snippet.publishedAt
    }));

    res.json(playlists);
  } catch (error) {
    console.error('Playlists error:', error);
    res.status(500).json({ error: 'Failed to fetch playlists' });
  }
});

/**
 * Get playlist items
 * GET /api/playlist/:playlistId/items
 */
app.get('/api/playlist/:playlistId/items', async (req, res) => {
  try {
    const { playlistId } = req.params;
    const { maxResults = 50, pageToken } = req.query;

    const params = {
      playlistId,
      part: 'snippet,contentDetails',
      maxResults,
      key: YOUTUBE_API_KEY
    };

    if (pageToken) {
      params.pageToken = pageToken;
    }

    const response = await axios.get(`${YOUTUBE_API_URL}/playlistItems`, { params });

    const items = response.data.items.map(item => ({
      id: item.id,
      videoId: item.snippet.resourceId.videoId,
      title: item.snippet.title,
      artist: item.snippet.videoOwnerChannelTitle,
      thumbnail: item.snippet.thumbnails?.medium?.url,
      addedAt: item.snippet.publishedAt
    }));

    res.json({
      items,
      nextPageToken: response.data.nextPageToken,
      totalResults: response.data.pageInfo.totalResults
    });
  } catch (error) {
    console.error('Playlist items error:', error);
    res.status(500).json({ error: 'Failed to fetch playlist items' });
  }
});

// ==================== LYRICS ENDPOINTS ====================

/**
 * Get song lyrics
 * GET /api/lyrics?artist=artist&title=title
 */
app.get('/api/lyrics', async (req, res) => {
  try {
    const { artist, title } = req.query;

    if (!artist || !title) {
      return res.status(400).json({ error: 'Artist and title required' });
    }

    // Check cache
    const cacheKey = `lyrics:${artist}:${title}`;
    const cachedResult = cache.get(cacheKey);
    if (cachedResult) {
      return res.json(cachedResult);
    }

    if (!GENIUS_ACCESS_TOKEN) {
      return res.status(400).json({ error: 'Genius API not configured' });
    }

    const lyrics = await getGeniusLyrics(artist, title);
    
    // Cache the result
    cache.set(cacheKey, lyrics);

    res.json(lyrics);
  } catch (error) {
    console.error('Lyrics error:', error);
    res.status(500).json({ error: 'Failed to fetch lyrics' });
  }
});

/**
 * Fetch lyrics from Genius API
 */
async function getGeniusLyrics(artist, title) {
  const params = {
    q: `${artist} ${title}`,
    access_token: GENIUS_ACCESS_TOKEN
  };

  const response = await axios.get('https://api.genius.com/search', { params });

  if (!response.data.response.hits.length) {
    return { lyrics: null, url: null };
  }

  const hit = response.data.response.hits[0];
  return {
    title: hit.result.title,
    artist: hit.result.primary_artist.name,
    url: hit.result.url,
    thumbnail: hit.result.song_art_image_thumbnail_url
  };
}

// ==================== RECOMMENDATION ENDPOINTS ====================

/**
 * Get song recommendations
 * GET /api/recommendations?seed=videoId&limit=20
 */
app.get('/api/recommendations', async (req, res) => {
  try {
    const { seed, limit = 20 } = req.query;

    if (!seed) {
      return res.status(400).json({ error: 'Seed video ID required' });
    }

    // Get details of seed song
    const seedDetails = await getSongDetails(seed);

    // Search for similar songs
    const recommendations = await searchYouTubeMusic(
      seedDetails.artist + ' ' + seedDetails.title,
      limit
    );

    res.json(recommendations);
  } catch (error) {
    console.error('Recommendations error:', error);
    res.status(500).json({ error: 'Failed to fetch recommendations' });
  }
});

// ==================== TRENDS ENDPOINTS ====================

/**
 * Get trending songs
 * GET /api/trending?region=US&limit=20
 */
app.get('/api/trending', async (req, res) => {
  try {
    const { region = 'US', limit = 20 } = req.query;

    // Check cache
    const cacheKey = `trending:${region}`;
    const cachedResult = cache.get(cacheKey);
    if (cachedResult) {
      return res.json(cachedResult);
    }

    const params = {
      part: 'snippet,contentDetails,statistics',
      chart: 'mostPopular',
      regionCode: region,
      videoCategoryId: '10', // Music category
      maxResults: limit,
      key: YOUTUBE_API_KEY
    };

    const response = await axios.get(`${YOUTUBE_API_URL}/videos`, { params });

    const trending = response.data.items.map(video => ({
      id: video.id,
      title: video.snippet.title,
      artist: video.snippet.channelTitle,
      thumbnail: video.snippet.thumbnails.high.url,
      duration: parseDuration(video.contentDetails.duration),
      views: parseInt(video.statistics.viewCount),
      likes: parseInt(video.statistics.likeCount || 0)
    }));

    // Cache the result
    cache.set(cacheKey, trending);

    res.json(trending);
  } catch (error) {
    console.error('Trending error:', error);
    res.status(500).json({ error: 'Failed to fetch trending songs' });
  }
});

// ==================== AUDIO STREAM ENDPOINTS ====================

/**
 * Get audio stream URL
 * GET /api/stream/:videoId
 */
app.get('/api/stream/:videoId', async (req, res) => {
  try {
    const { videoId } = req.params;

    // In production, you would use a library like ytdl-core or similar
    // This is a placeholder that returns the YouTube player URL
    const streamUrl = `https://www.youtube.com/watch?v=${videoId}`;

    res.json({
      url: streamUrl,
      format: 'mp4',
      quality: 'hd'
    });
  } catch (error) {
    console.error('Stream error:', error);
    res.status(500).json({ error: 'Failed to get stream' });
  }
});

// ==================== HEALTH CHECK ====================

app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// ==================== ERROR HANDLING ====================

app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal server error',
    timestamp: new Date().toISOString()
  });
});

// ==================== START SERVER ====================

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Music API Server running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`YouTube API Key: ${YOUTUBE_API_KEY ? 'Configured' : 'Missing'}`);
});

module.exports = app;
