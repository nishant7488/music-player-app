# 🎵 Sonic Wave - Full-Featured Music Streaming System

A production-ready music streaming application built with React and the YouTube Music API. Features real-time search, playback controls, playlist management, and a beautiful modern UI.

![Music App](https://img.shields.io/badge/React-18.2.0-blue?style=flat-square)
![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)
![Node Version](https://img.shields.io/badge/Node-14+-green?style=flat-square)

---

## ✨ Features

### 🎵 Music Playback
- ▶️ Play/pause controls with real-time progress
- ⏭️ Next/previous track navigation
- 🔊 Volume control with visual feedback
- ⏱️ Time tracking with formatted display
- 📊 Progress bar with seek functionality
- 🎯 Queue management system

### 🔍 Discovery & Search
- 🔎 Real-time song, artist, and album search
- 🎬 High-quality thumbnail previews
- 📈 Trending songs by region
- 💡 Smart recommendations based on seed songs
- 🎨 Beautiful card-based UI for results
- 📄 Pagination support for large result sets

### ❤️ Library Management
- 💝 Like/unlike songs with persistent storage
- 📚 Create and manage custom playlists
- 🕐 Recently played history tracking
- 🎵 Drag-and-drop playlist editing
- 📊 Listening statistics and analytics
- 🏷️ Song tagging and categorization

### 🎨 Beautiful User Interface
- 🌙 Dark theme with vibrant gradient background
- ✨ Glassmorphism effects with blur backdrop
- 🎭 Smooth animations and transitions
- 📱 Fully responsive design
- ♿ Accessibility features
- 🎯 Intuitive navigation

### 🔧 Developer Features
- 🚀 RESTful API with comprehensive endpoints
- 🔐 Secure API key management
- 📦 Local caching for better performance
- 🔄 Rate limiting and error handling
- 🧪 Easy to test and extend
- 📝 Well-documented code

---

## 🚀 Quick Start

### Installation (2 minutes)

```bash
# 1. Clone the repository
git clone https://github.com/yourusername/music-app.git
cd music-app

# 2. Install dependencies
npm install

# 3. Setup environment variables
cp .env.example .env.local

# 4. Add your YouTube API key to .env.local
# REACT_APP_YOUTUBE_MUSIC_API_KEY=your_key_here

# 5. Start the application
npm run dev  # Starts both React app and backend

# OR in separate terminals:
npm start    # React app (port 3000)
npm run server  # Backend (port 5000)
```

Visit `http://localhost:3000` and enjoy! 🎉

---

## 📋 Detailed Setup Guide

### Prerequisites
- **Node.js** v14 or higher
- **npm** v6 or higher
- **YouTube API Key** (free from Google Cloud)

### Step 1: Get YouTube API Credentials

1. Visit [Google Cloud Console](https://console.cloud.google.com)
2. Create a new project
3. Enable "YouTube Data API v3":
   - Go to APIs & Services → Library
   - Search for "YouTube Data API v3"
   - Click Enable
4. Create API credentials:
   - Go to APIs & Services → Credentials
   - Click "Create Credentials" → API Key
   - Copy your API key

### Step 2: Clone & Setup

```bash
# Clone the project
git clone https://github.com/yourusername/music-app.git
cd music-app

# Install all dependencies
npm install

# Create environment file
cp .env.example .env.local
```

### Step 3: Configure Environment

Edit `.env.local`:
```env
REACT_APP_YOUTUBE_MUSIC_API_KEY=your_youtube_api_key_here
REACT_APP_API_BASE_URL=http://localhost:5000/api
SPOTIFY_CLIENT_ID=optional_spotify_key
GENIUS_ACCESS_TOKEN=optional_genius_key
```

### Step 4: Run the Application

```bash
# Development mode with hot reload
npm run dev

# OR manually in two terminals:

# Terminal 1: React frontend
npm start

# Terminal 2: Node.js backend
npm run server
```

The app opens automatically at `http://localhost:3000`

---

## 📁 Project Structure

```
music-app/
├── music_app.jsx              # Main React component (1000+ lines)
│   ├── Search functionality
│   ├── Playback controls
│   ├── Playlist management
│   └── UI components
│
├── backend_server.js          # Express.js backend server
│   ├── Search endpoints
│   ├── Song details
│   ├── Playlist management
│   ├── Recommendations
│   ├── Trending songs
│   └── Error handling
│
├── api_utils.js               # Utility functions
│   ├── API call wrappers
│   ├── Local storage managers
│   ├── Formatting helpers
│   └── Validation functions
│
├── package.json               # Dependencies
├── .env.example              # Environment template
├── QUICKSTART.md             # Quick start guide
└── SETUP_GUIDE.md            # Detailed documentation
```

---

## 🎯 Core Features Explained

### 1. Search System
```javascript
// Search songs in real-time
searchSongs('Imagine Dragons', 20)
// Returns: { items: [...], nextPageToken: '...' }
```

### 2. Playback Management
```javascript
// Play a song
playSong(song)
// Toggle play/pause
togglePlayPause()
// Navigate queue
nextTrack() / prevTrack()
```

### 3. Playlist Management
```javascript
// Create custom playlists
playlistManager.create('My Favorites')
// Add songs
playlistManager.addSong(playlistId, songData)
// Remove songs
playlistManager.removeSong(playlistId, songId)
```

### 4. Likes & History
```javascript
// Like a song
likedSongsManager.add(songId, songData)
// Add to history
historyManager.addToHistory(songData)
// Get recent songs
historyManager.getRecentSongs(10)
```

---

## 🔌 API Endpoints

### Search
```
GET /api/search?q=query&limit=20
GET /api/search?q=query&type=artist
```

### Songs
```
GET /api/song/:videoId
GET /api/song/:videoId/lyrics
GET /api/trending?region=US&limit=20
```

### Recommendations
```
GET /api/recommendations?seed=videoId&limit=20
```

### Playlists
```
GET /api/playlists/:channelId
GET /api/playlist/:playlistId/items
```

### Streaming
```
GET /api/stream/:videoId
```

---

## 🎨 Customization

### Change Theme Colors

Edit in `music_app.jsx`:
```javascript
// Background gradient
background: 'linear-gradient(135deg, #your_color1, #your_color2, #your_color3)'

// Primary accent color
backgroundColor: 'linear-gradient(135deg, #your_accent, #your_secondary)'
```

### Modify Card Layout

```javascript
// In song grid section
gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))'
// Change to auto-fill with different minmax values
```

### Add New Features

1. **Shuffle Mode**: Add random queue generation
2. **Repeat Modes**: One, All, Off
3. **Equalizer**: Web Audio API controls
4. **Visualizer**: Canvas-based audio visualization
5. **Lyrics Display**: Full lyric view with sync
6. **Social Sharing**: Share songs on social media

---

## 🧪 Testing

### Run Tests
```bash
npm test
```

### Test Specific Feature
```bash
npm test searchSongs.test.js
```

### Example Test
```javascript
describe('MusicApp', () => {
  it('should play a song', () => {
    const { getByRole } = render(<MusicApp />);
    const playButton = getByRole('button', { name: /play/i });
    fireEvent.click(playButton);
    expect(playButton).toHaveAttribute('aria-pressed', 'true');
  });
});
```

---

## 🚀 Deployment

### Deploy Frontend to Vercel
```bash
npm install -g vercel
vercel
```

### Deploy Frontend to Netlify
```bash
npm run build
# Drag build folder to Netlify or use CLI
netlify deploy --prod --dir=build
```

### Deploy Backend to Heroku
```bash
heroku create your-app-name
heroku config:set YOUTUBE_API_KEY=your_key
git push heroku main
```

### Deploy with Docker
```bash
# Build image
docker build -t music-app .

# Run container
docker run -p 3000:3000 -p 5000:5000 music-app
```

---

## 🔐 Security Best Practices

### API Key Management
- ✅ Never commit `.env` files
- ✅ Use environment variables for sensitive data
- ✅ Rotate keys periodically
- ✅ Restrict API key permissions

### CORS Configuration
```javascript
const corsOptions = {
  origin: process.env.FRONTEND_URL,
  credentials: true,
  optionsSuccessStatus: 200
};
app.use(cors(corsOptions));
```

### Rate Limiting
```javascript
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100
});
app.use(limiter);
```

---

## 🐛 Troubleshooting

| Issue | Solution |
|-------|----------|
| API Key Invalid | Verify API is enabled and has correct permissions |
| CORS Error | Ensure backend is running and correct URL in .env |
| No Search Results | Check internet, verify YouTube API quota |
| Audio Not Playing | Ensure video can be embedded, check browser console |
| Port Already in Use | Change PORT in .env or kill existing process |

---

## 📊 Performance Optimization

### Code Splitting
```javascript
const NowPlayingBar = React.lazy(() => import('./NowPlayingBar'));
```

### Memoization
```javascript
const SongCard = React.memo(({ song, onPlay }) => {
  return /* JSX */
});
```

### Caching
```javascript
// Backend caching with NodeCache
const cache = new NodeCache({ stdTTL: 600 });
```

### Lazy Loading
```javascript
// Infinite scroll with Intersection Observer
const observer = new IntersectionObserver(entries => {
  if (entries[0].isIntersecting) loadMore();
});
```

---

## 🎓 Learning Resources

- [React Documentation](https://react.dev) - Learn React
- [YouTube Data API](https://developers.google.com/youtube/v3) - API Reference
- [Web Audio API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API) - Audio Control
- [Express.js Guide](https://expressjs.com/) - Backend Framework
- [CSS-in-JS Best Practices](https://styled-components.com/) - Styling

---

## 🤝 Contributing

We welcome contributions! Here's how:

1. **Fork** the repository
2. **Create** a feature branch (`git checkout -b feature/amazing-feature`)
3. **Commit** your changes (`git commit -m 'Add amazing feature'`)
4. **Push** to the branch (`git push origin feature/amazing-feature`)
5. **Open** a Pull Request

### Contribution Guidelines
- Follow the existing code style
- Add tests for new features
- Update documentation
- Keep commits atomic and descriptive

---

## 📝 License

MIT License - See LICENSE file for details

This means you can use this project freely for personal and commercial purposes!

---

## 🙏 Acknowledgments

- YouTube Music API for providing music data
- Lucide React for beautiful icons
- The open-source community for inspiration

---

## 📞 Support & Contact

### Having Issues?
- 📖 Check [QUICKSTART.md](QUICKSTART.md) for quick help
- 📚 Read [SETUP_GUIDE.md](SETUP_GUIDE.md) for detailed setup
- 🐛 Open an issue on GitHub
- 💬 Join our community Discord

### Found a Bug?
Please report it with:
- Browser and OS version
- Steps to reproduce
- Expected vs actual behavior
- Console error messages

---

## 🎯 Roadmap

### v1.0 (Current)
- ✅ Search functionality
- ✅ Basic playback
- ✅ Liked songs
- ✅ Playlists

### v1.1 (Coming Soon)
- 🔄 User accounts
- 🔄 Social features
- 🔄 Offline mode
- 🔄 Custom themes

### v2.0 (Future)
- 🎵 Spotify integration
- 🎨 Advanced visualizer
- 🌐 Web3 integration
- 📱 Native mobile apps

---

## 💡 Pro Tips

1. **Speed**: Use debouncing on search inputs
2. **Data**: Cache results in localStorage
3. **UX**: Implement skeleton loaders
4. **Performance**: Use React.memo for list items
5. **Features**: Add keyboard shortcuts
6. **Testing**: Write tests as you code
7. **Deployment**: Use environment-specific configs

---

**Made with ❤️ for music lovers everywhere**

---

## Quick Links

- [GitHub Repository](https://github.com)
- [Report a Bug](https://github.com/issues)
- [Request a Feature](https://github.com/issues)
- [Documentation](SETUP_GUIDE.md)
- [Quick Start](QUICKSTART.md)

---

**Last Updated**: February 2025  
**Version**: 1.0.0  
**Status**: ✅ Production Ready
