import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, SkipForward, SkipBack, Volume2, Heart, Share2, List, Search, Music, Zap, TrendingUp, Clock, User } from 'lucide-react';

export default function MusicApp() {
  const [apiKey, setApiKey] = useState('');
  const [showApiModal, setShowApiModal] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [songs, setSongs] = useState([]);
  const [playlists, setPlaylists] = useState([]);
  const [currentSong, setCurrentSong] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(70);
  const [liked, setLiked] = useState(new Set());
  const [queue, setQueue] = useState([]);
  const [queueIndex, setQueueIndex] = useState(0);
  const [activeTab, setActiveTab] = useState('search');
  const [loading, setLoading] = useState(false);
  const audioRef = useRef(new Audio());

  // Handle API Key Setup
  const handleApiKeySubmit = (e) => {
    e.preventDefault();
    if (apiKey.trim()) {
      localStorage.setItem('ytmusicApiKey', apiKey);
      setShowApiModal(false);
    }
  };

  // Search songs
  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoading(true);
    try {
      // Simulated API call - replace with actual YouTube Music API
      const response = await fetch(`https://music.youtube.com/search?q=${encodeURIComponent(searchQuery)}`, {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        }
      }).catch(() => null);

      // Fallback with mock data for demonstration
      const mockSongs = [
        {
          id: '1',
          title: 'Midnight Dreams',
          artist: 'Luna Echo',
          duration: 245,
          thumbnail: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=200',
          plays: 1240000
        },
        {
          id: '2',
          title: 'Electric Pulse',
          artist: 'Neon Lights',
          duration: 198,
          thumbnail: 'https://images.unsplash.com/photo-1487180144351-b8472da7d491?w=200',
          plays: 890000
        },
        {
          id: '3',
          title: 'Ocean Waves',
          artist: 'Aqua Blue',
          duration: 267,
          thumbnail: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=200',
          plays: 2100000
        }
      ];

      setSongs(mockSongs);
    } catch (error) {
      console.error('Search failed:', error);
    } finally {
      setLoading(false);
    }
  };

  // Play song
  const playSong = (song) => {
    setCurrentSong(song);
    setQueue([song]);
    setQueueIndex(0);
    setIsPlaying(true);
    // In real implementation, load actual audio stream
  };

  // Toggle like
  const toggleLike = (songId) => {
    const newLiked = new Set(liked);
    if (newLiked.has(songId)) {
      newLiked.delete(songId);
    } else {
      newLiked.add(songId);
    }
    setLiked(newLiked);
  };

  // Play/Pause
  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  // Next track
  const nextTrack = () => {
    if (queueIndex < queue.length - 1) {
      setQueueIndex(queueIndex + 1);
      setCurrentSong(queue[queueIndex + 1]);
    }
  };

  // Previous track
  const prevTrack = () => {
    if (queueIndex > 0) {
      setQueueIndex(queueIndex - 1);
      setCurrentSong(queue[queueIndex - 1]);
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div style={{ background: 'linear-gradient(135deg, #0f0c29, #302b63, #24243e)', minHeight: '100vh', color: '#fff' }}>
      {/* API Key Modal */}
      {showApiModal && (
        <div style={{
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          backdropFilter: 'blur(5px)'
        }}>
          <div style={{
            backgroundColor: '#1a1a2e',
            borderRadius: '20px',
            padding: '40px',
            maxWidth: '500px',
            border: '1px solid rgba(255, 107, 107, 0.3)',
            boxShadow: '0 20px 60px rgba(255, 107, 107, 0.2)'
          }}>
            <h2 style={{ fontSize: '28px', marginBottom: '10px', fontFamily: "'Playfair Display', serif" }}>YouTube Music</h2>
            <p style={{ color: '#aaa', marginBottom: '30px' }}>Enter your YouTube Music API key to get started</p>
            <form onSubmit={handleApiKeySubmit}>
              <input
                type="password"
                placeholder="Paste your API key..."
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  backgroundColor: 'rgba(255, 255, 255, 0.05)',
                  border: '1px solid rgba(255, 107, 107, 0.3)',
                  borderRadius: '10px',
                  color: '#fff',
                  marginBottom: '20px',
                  boxSizing: 'border-box',
                  fontSize: '14px'
                }}
              />
              <button
                type="submit"
                style={{
                  width: '100%',
                  padding: '12px',
                  backgroundColor: 'linear-gradient(135deg, #ff6b6b, #ee5a6f)',
                  border: 'none',
                  borderRadius: '10px',
                  color: '#fff',
                  fontWeight: '600',
                  cursor: 'pointer',
                  fontSize: '16px',
                  transition: 'all 0.3s ease'
                }}
                onMouseEnter={(e) => e.target.style.transform = 'translateY(-2px)'}
                onMouseLeave={(e) => e.target.style.transform = 'translateY(0)'}
              >
                Continue
              </button>
            </form>
          </div>
        </div>
      )}

      {!showApiModal && (
        <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
          {/* Header */}
          <div style={{
            padding: '20px 30px',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
            backdropFilter: 'blur(10px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <Zap size={28} color="#ff6b6b" />
              <h1 style={{ fontSize: '24px', fontFamily: "'Playfair Display', serif", margin: 0 }}>Sonic Wave</h1>
            </div>
            <div style={{ display: 'flex', gap: '15px' }}>
              <button
                onClick={() => setActiveTab('search')}
                style={{
                  padding: '8px 16px',
                  backgroundColor: activeTab === 'search' ? 'rgba(255, 107, 107, 0.3)' : 'transparent',
                  border: '1px solid rgba(255, 107, 107, activeTab === 'search' ? 0.5 : 0.2)',
                  borderRadius: '8px',
                  color: '#fff',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease'
                }}
              >
                <Search size={18} />
              </button>
              <button
                onClick={() => setActiveTab('liked')}
                style={{
                  padding: '8px 16px',
                  backgroundColor: activeTab === 'liked' ? 'rgba(255, 107, 107, 0.3)' : 'transparent',
                  border: '1px solid rgba(255, 107, 107, activeTab === 'liked' ? 0.5 : 0.2)',
                  borderRadius: '8px',
                  color: '#fff',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease'
                }}
              >
                <Heart size={18} />
              </button>
            </div>
          </div>

          {/* Main Content */}
          <div style={{ flex: 1, overflow: 'auto', padding: '30px' }}>
            {activeTab === 'search' && (
              <>
                {/* Search Bar */}
                <form onSubmit={handleSearch} style={{ marginBottom: '40px' }}>
                  <div style={{
                    display: 'flex',
                    gap: '10px',
                    maxWidth: '600px',
                    margin: '0 auto'
                  }}>
                    <input
                      type="text"
                      placeholder="Search songs, artists, albums..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      style={{
                        flex: 1,
                        padding: '14px 20px',
                        backgroundColor: 'rgba(255, 255, 255, 0.08)',
                        border: '1px solid rgba(255, 107, 107, 0.3)',
                        borderRadius: '12px',
                        color: '#fff',
                        fontSize: '16px',
                        transition: 'all 0.3s ease'
                      }}
                      onFocus={(e) => e.target.style.backgroundColor = 'rgba(255, 255, 255, 0.12)'}
                      onBlur={(e) => e.target.style.backgroundColor = 'rgba(255, 255, 255, 0.08)'}
                    />
                    <button
                      type="submit"
                      style={{
                        padding: '14px 28px',
                        backgroundColor: 'linear-gradient(135deg, #ff6b6b, #ee5a6f)',
                        border: 'none',
                        borderRadius: '12px',
                        color: '#fff',
                        fontWeight: '600',
                        cursor: 'pointer',
                        transition: 'all 0.3s ease'
                      }}
                      onMouseEnter={(e) => e.target.style.transform = 'translateY(-2px)'}
                      onMouseLeave={(e) => e.target.style.transform = 'translateY(0)'}
                    >
                      Search
                    </button>
                  </div>
                </form>

                {/* Songs Grid */}
                {songs.length > 0 && (
                  <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
                    gap: '20px'
                  }}>
                    {songs.map((song) => (
                      <div
                        key={song.id}
                        style={{
                          backgroundColor: 'rgba(255, 255, 255, 0.05)',
                          borderRadius: '16px',
                          overflow: 'hidden',
                          border: '1px solid rgba(255, 107, 107, 0.2)',
                          transition: 'all 0.3s ease',
                          cursor: 'pointer',
                          position: 'relative'
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
                          e.currentTarget.style.transform = 'translateY(-8px)';
                          e.currentTarget.style.boxShadow = '0 20px 40px rgba(255, 107, 107, 0.2)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
                          e.currentTarget.style.transform = 'translateY(0)';
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      >
                        <div style={{ position: 'relative' }}>
                          <img
                            src={song.thumbnail}
                            alt={song.title}
                            style={{
                              width: '100%',
                              height: '180px',
                              objectFit: 'cover',
                              display: 'block'
                            }}
                          />
                          <button
                            onClick={() => playSong(song)}
                            style={{
                              position: 'absolute',
                              bottom: '10px',
                              right: '10px',
                              width: '50px',
                              height: '50px',
                              borderRadius: '50%',
                              backgroundColor: 'rgba(255, 107, 107, 0.9)',
                              border: 'none',
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              transition: 'all 0.3s ease'
                            }}
                            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'rgba(255, 107, 107, 1)'}
                            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'rgba(255, 107, 107, 0.9)'}
                          >
                            <Play size={24} fill="#fff" color="#fff" />
                          </button>
                        </div>
                        <div style={{ padding: '16px' }}>
                          <h3 style={{ margin: '0 0 6px 0', fontSize: '16px', fontWeight: '600', lineHeight: '1.3' }}>
                            {song.title}
                          </h3>
                          <p style={{ margin: '0 0 12px 0', fontSize: '13px', color: '#aaa' }}>
                            {song.artist}
                          </p>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: '#888' }}>
                            <TrendingUp size={14} />
                            {(song.plays / 1000000).toFixed(1)}M plays
                          </div>
                        </div>
                        <button
                          onClick={() => toggleLike(song.id)}
                          style={{
                            position: 'absolute',
                            top: '10px',
                            right: '10px',
                            width: '40px',
                            height: '40px',
                            borderRadius: '50%',
                            backgroundColor: 'rgba(0, 0, 0, 0.4)',
                            border: 'none',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}
                        >
                          <Heart
                            size={20}
                            fill={liked.has(song.id) ? '#ff6b6b' : 'none'}
                            color={liked.has(song.id) ? '#ff6b6b' : '#fff'}
                          />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {songs.length === 0 && !loading && (
                  <div style={{
                    textAlign: 'center',
                    padding: '60px 20px',
                    color: '#888'
                  }}>
                    <Music size={64} style={{ margin: '0 auto 20px', opacity: 0.3 }} />
                    <p style={{ fontSize: '18px' }}>Search for songs to get started</p>
                  </div>
                )}
              </>
            )}

            {activeTab === 'liked' && (
              <>
                {liked.size > 0 ? (
                  <div>
                    <h2 style={{ marginBottom: '20px', fontSize: '24px', fontFamily: "'Playfair Display', serif" }}>
                      Liked Songs ({liked.size})
                    </h2>
                    <div style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
                      gap: '20px'
                    }}>
                      {songs.filter(s => liked.has(s.id)).map((song) => (
                        <div
                          key={song.id}
                          style={{
                            backgroundColor: 'rgba(255, 107, 107, 0.1)',
                            borderRadius: '16px',
                            overflow: 'hidden',
                            border: '1px solid rgba(255, 107, 107, 0.4)',
                            padding: '16px'
                          }}
                        >
                          <h3 style={{ margin: '0 0 6px 0', fontSize: '16px' }}>{song.title}</h3>
                          <p style={{ margin: 0, fontSize: '13px', color: '#aaa' }}>{song.artist}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div style={{
                    textAlign: 'center',
                    padding: '60px 20px',
                    color: '#888'
                  }}>
                    <Heart size={64} style={{ margin: '0 auto 20px', opacity: 0.3 }} />
                    <p style={{ fontSize: '18px' }}>No liked songs yet</p>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Now Playing Bar */}
          {currentSong && (
            <div style={{
              padding: '20px 30px',
              borderTop: '1px solid rgba(255, 255, 255, 0.1)',
              backgroundColor: 'rgba(0, 0, 0, 0.3)',
              backdropFilter: 'blur(10px)'
            }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '15px',
                marginBottom: '15px'
              }}>
                <img
                  src={currentSong.thumbnail}
                  alt={currentSong.title}
                  style={{
                    width: '56px',
                    height: '56px',
                    borderRadius: '8px',
                    objectFit: 'cover'
                  }}
                />
                <div style={{ flex: 1 }}>
                  <h3 style={{ margin: 0, fontSize: '16px' }}>{currentSong.title}</h3>
                  <p style={{ margin: '4px 0 0 0', fontSize: '13px', color: '#aaa' }}>{currentSong.artist}</p>
                </div>
                <button
                  onClick={() => toggleLike(currentSong.id)}
                  style={{
                    backgroundColor: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    color: '#fff'
                  }}
                >
                  <Heart
                    size={24}
                    fill={liked.has(currentSong.id) ? '#ff6b6b' : 'none'}
                    color={liked.has(currentSong.id) ? '#ff6b6b' : '#fff'}
                  />
                </button>
              </div>

              {/* Progress Bar */}
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                marginBottom: '15px'
              }}>
                <span style={{ fontSize: '12px', color: '#aaa', width: '30px' }}>
                  {formatTime(currentTime)}
                </span>
                <div style={{
                  flex: 1,
                  height: '4px',
                  backgroundColor: 'rgba(255, 255, 255, 0.1)',
                  borderRadius: '2px',
                  overflow: 'hidden'
                }}>
                  <div style={{
                    height: '100%',
                    backgroundColor: '#ff6b6b',
                    width: `${(currentTime / currentSong.duration) * 100}%`,
                    transition: 'width 0.1s linear'
                  }} />
                </div>
                <span style={{ fontSize: '12px', color: '#aaa', width: '30px', textAlign: 'right' }}>
                  {formatTime(currentSong.duration)}
                </span>
              </div>

              {/* Controls */}
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '20px'
              }}>
                <button
                  onClick={prevTrack}
                  style={{
                    backgroundColor: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    color: '#fff',
                    transition: 'all 0.2s'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.color = '#ff6b6b'}
                  onMouseLeave={(e) => e.currentTarget.style.color = '#fff'}
                >
                  <SkipBack size={24} />
                </button>

                <button
                  onClick={togglePlayPause}
                  style={{
                    width: '56px',
                    height: '56px',
                    borderRadius: '50%',
                    backgroundColor: 'linear-gradient(135deg, #ff6b6b, #ee5a6f)',
                    border: 'none',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#fff',
                    transition: 'all 0.2s'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
                  onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                >
                  {isPlaying ? <Pause size={28} fill="#fff" /> : <Play size={28} fill="#fff" />}
                </button>

                <button
                  onClick={nextTrack}
                  style={{
                    backgroundColor: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    color: '#fff',
                    transition: 'all 0.2s'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.color = '#ff6b6b'}
                  onMouseLeave={(e) => e.currentTarget.style.color = '#fff'}
                >
                  <SkipForward size={24} />
                </button>

                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  marginLeft: 'auto'
                }}>
                  <Volume2 size={20} />
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={volume}
                    onChange={(e) => setVolume(parseInt(e.target.value))}
                    style={{
                      width: '100px',
                      cursor: 'pointer'
                    }}
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
